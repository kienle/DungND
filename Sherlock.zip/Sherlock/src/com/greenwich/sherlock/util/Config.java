package com.greenwich.sherlock.util;

public class Config {
	public static final String USERNAME = "user";
	public static final String PASSWORD = "password";
	public static final String USER_OBJECT = "user";
	public static final String USER_LOCATION_OBJECT = "user_location";
	public static final String IS_NEW = "is_new";
	public static final String USER_ID = "user_id";
	public static final String IS_VIEW = "is_view";
}